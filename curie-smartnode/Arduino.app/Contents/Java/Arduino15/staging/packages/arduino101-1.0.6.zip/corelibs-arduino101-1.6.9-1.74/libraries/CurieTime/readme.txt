Readme file for CurieTime Library

The CurieTime library is provided to demonstrate the Arduino101 Time library.

See the CurieTime example sketches provided with the Arduino101 Time library download for usage


